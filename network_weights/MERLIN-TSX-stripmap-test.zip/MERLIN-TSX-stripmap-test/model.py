from utils import *
from u_net import *
M = 10.089038980848645
m = -1.429329123112601

class denoiser(object):
    def __init__(self, sess, input_c_dim=1):
        self.sess = sess
        self.input_c_dim = input_c_dim
        self.Y_ = tf.placeholder(tf.float32, [None, None, None, self.input_c_dim],
                                 name='noisy_image')
        self.Y_input = (tf.math.log(tf.square(self.Y_)+1e-3)-2*m)/(2*(M-m)) # normalize between 0 and 1

        self.R = autoencoder((self.Y_input))
        init = tf.global_variables_initializer()
        self.sess.run(init)
        print("[*] Initialize model successfully...")

    def load(self, checkpoint_dir):
        print("[*] Reading checkpoint...")
        saver = tf.train.Saver()
        ckpt = tf.train.get_checkpoint_state(checkpoint_dir)
        if ckpt and ckpt.model_checkpoint_path:
            full_path = tf.train.latest_checkpoint(checkpoint_dir)
            saver.restore(self.sess, full_path)
            return True
        else:
            return False

    def test(self, test_files, ckpt_dir, save_dir, dataset_dir, stride):
        """Test MERLIN"""
        tf.initialize_all_variables().run()
        assert len(test_files) != 0, 'No testing data!'
        load_model_status = self.load(ckpt_dir)
        assert load_model_status == True, '[!] Load weights FAILED...'
        print(" [*] Load weights SUCCESS...")
        print("[*] start testing...")
        for idx in range(len(test_files)):
            real_image = load_sar_images(test_files[idx]).astype(np.float32)
            i_real_part = (real_image[:, :, :, 0]).reshape(real_image.shape[0], real_image.shape[1],
                                                           real_image.shape[2], 1)
            i_imag_part = (real_image[:, :, :, 1]).reshape(real_image.shape[0], real_image.shape[1],
                                                           real_image.shape[2], 1)
            # scan on image dimensions
            stride = 64
            pat_size = 256
            # Pad the image
            im_h = np.size(real_image, 1)
            im_w = np.size(real_image, 2)

            count_image = np.zeros(i_real_part.shape)
            output_clean_image_1 = np.zeros(i_real_part.shape)
            output_clean_image_2 = np.zeros(i_real_part.shape)
            if im_h == pat_size:
                x_range = list(np.array([0]))
            else:
                x_range = list(range(0, im_h - pat_size, stride))
                if (x_range[-1] + pat_size) < im_h: x_range.extend(range(im_h - pat_size, im_h - pat_size + 1))

            if im_w == pat_size:
                y_range = list(np.array([0]))
            else:
                y_range = list(range(0, im_w - pat_size, stride))
                if (y_range[-1] + pat_size) < im_w: y_range.extend(range(im_w - pat_size, im_w - pat_size + 1))

            for x in x_range:
                for y in y_range:
                    real_to_denoise, imag_to_denoise = symetrisation_patch_test(i_real_part[:, x:x + pat_size, y:y + pat_size, :],i_imag_part[:, x:x + pat_size, y:y + pat_size, :])
                    tmp_clean_image_real = self.sess.run([self.R],
                                                         feed_dict={self.Y_: real_to_denoise})
                    output_clean_image_1[:, x:x + pat_size, y:y + pat_size, :] = output_clean_image_1[:, x:x + pat_size,
                                                                                 y:y + pat_size,
                                                                                 :] + tmp_clean_image_real
                    tmp_clean_image_imag = self.sess.run([self.R],
                                                         feed_dict={self.Y_: imag_to_denoise})
                    output_clean_image_2[:, x:x + pat_size, y:y + pat_size, :] = output_clean_image_2[:, x:x + pat_size,
                                                                                 y:y + pat_size,
                                                                                 :] + tmp_clean_image_imag
                    count_image[:, x:x + pat_size, y:y + pat_size, :] = count_image[:, x:x + pat_size, y:y + pat_size,
                                                                        :] + np.ones((1, pat_size, pat_size, 1))
            output_clean_image_1 = output_clean_image_1 / count_image
            output_clean_image_2 = output_clean_image_2 / count_image
            output_clean_image = 0.5 * (np.square(denormalize_sar(output_clean_image_1)) + np.square(
                denormalize_sar(output_clean_image_2))) # combine the two estimation


            noisyimage = np.squeeze(np.sqrt(i_real_part ** 2 + i_imag_part ** 2))
            outputimage = np.sqrt(np.squeeze(output_clean_image))

            imagename = test_files[idx].replace(dataset_dir+"/", "")
            print("Denoised image %s" % imagename)

            save_sar_images(outputimage, noisyimage, imagename, save_dir)
            save_real_imag_images(noisyimage, denormalize_sar(output_clean_image_1), denormalize_sar(output_clean_image_2),
                                  imagename, save_dir)
            save_real_imag_images_noisy(noisyimage, np.squeeze(i_real_part), np.squeeze(i_imag_part), imagename, save_dir)
